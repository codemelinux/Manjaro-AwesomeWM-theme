#!/bin/bash

conky -c $HOME/.config/awesome/conky/conky1.10_shortcuts_green &&
conky -c $HOME/.config/awesome/conky/conky_green &&

exit 0
