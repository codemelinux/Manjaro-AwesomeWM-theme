#!/bin/bash

conky -c /usr/share/conky/conky1.10_shortcuts_grey &&
conky -c /usr/share/conky/conky_grey &&

exit 0
