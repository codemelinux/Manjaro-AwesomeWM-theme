#!/bin/bash

conky -c /usr/share/conky/conky_shortcuts_live_green &&
conky -c /usr/share/conky/conky_green

exit 0
