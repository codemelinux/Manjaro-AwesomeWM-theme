#!/bin/bash

conky -c /usr/share/conky/conky_shortcuts_live_grey &&
conky -c /usr/share/conky/conky_grey

exit 0
