#!/bin/bash

conky -c /usr/share/conky/conky_shortcuts_live_maia &&
conky -c /usr/share/conky/conky_maia

exit 0
