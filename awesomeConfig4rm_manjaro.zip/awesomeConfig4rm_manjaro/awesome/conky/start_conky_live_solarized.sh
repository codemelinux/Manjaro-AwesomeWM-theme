#!/bin/bash

conky -c /usr/share/conky/conky_shortcuts_live_solarized &&
conky -c /usr/share/conky/conky_solarized &&

exit 0
