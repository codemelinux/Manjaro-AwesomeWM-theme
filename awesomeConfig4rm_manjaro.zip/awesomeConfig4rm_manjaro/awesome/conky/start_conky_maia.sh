#!/bin/bash

conky -c /usr/share/conky/conky1.10_shortcuts_maia &&
conky -c /usr/share/conky/conky_maia &&

exit 0
