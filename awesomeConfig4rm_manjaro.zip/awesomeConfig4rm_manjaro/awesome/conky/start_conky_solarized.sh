#!/bin/bash

conky -c /usr/share/conky/conky1.10_shortcuts_solarized &&
conky -c /usr/share/conky/conky_solarized &&

exit 0
